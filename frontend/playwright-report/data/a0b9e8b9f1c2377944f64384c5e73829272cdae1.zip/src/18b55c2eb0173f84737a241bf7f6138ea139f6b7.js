import { test, expect } from '@playwright/test'
import { loginCustomer } from './helpers'

test.describe('Voucher', () => {
  test.beforeEach(async ({ page }) => { await loginCustomer(page); await page.goto('/#cart') })

  test('TC-21 voucher input is available', async ({ page }) => {
    await expect(page.getByPlaceholder(/mã|voucher/i).first()).toBeVisible()
  })

  test('TC-22 invalid voucher is rejected in UI', async ({ page }) => {
    const input = page.getByPlaceholder(/mã|voucher/i).first()
    await input.fill('INVALID-CODE')
    await page.getByRole('button', { name: /Áp dụng/i }).click()
    await expect(page.getByText(/không hợp lệ|không tồn tại|mã/i).last()).toBeVisible()
  })
})