import { test, expect } from '@playwright/test'
import { loginCustomer } from './helpers'

test.describe('Smart Size', () => {
  test.beforeEach(async ({ page }) => { await loginCustomer(page); await page.goto('/#recommendation') })

  test('TC-39 valid body measurements return a recommendation', async ({ page }) => {
    await page.getByRole('button', { name: /Gợi ý size|Nhận gợi ý/i }).click()
    await expect(page.getByText(/size|BMI|dáng/i).last()).toBeVisible()
  })

  test('TC-40 boundary measurements remain editable', async ({ page }) => {
    const height = page.getByLabel('Chiều cao')
    await height.fill('120')
    await expect(height).toHaveValue('120')
  })

  test('TC-41 style recommendation controls render', async ({ page }) => {
    await expect(page.getByText(/Gợi ý phong cách|Phối đồ/i).first()).toBeVisible()
    await expect(page.getByRole('button', { name: 'Công sở' })).toBeVisible()
  })
})