import { test, expect } from '@playwright/test'
import { loginCustomer, openFirstProduct } from './helpers'

test.describe('Wishlist', () => {
  test.beforeEach(async ({ page }) => { await loginCustomer(page) })

  test('TC-36 wishlist page loads', async ({ page }) => {
    await page.goto('/#wishlist')
    await expect(page.getByRole('heading', { name: /yêu thích/i })).toBeVisible()
  })

  test('TC-37 product can be added to wishlist', async ({ page }) => {
    await openFirstProduct(page)
    await page.getByRole('button', { name: /Thêm vào yêu thích/i }).click()
    await expect(page.getByRole('button', { name: /Bỏ yêu thích/i })).toBeVisible()
  })

  test('TC-38 wishlist toggle removes product', async ({ page }) => {
    await openFirstProduct(page)
    const toggle = page.getByRole('button', { name: /Thêm vào yêu thích|Bỏ yêu thích/i })
    await toggle.click()
    await page.getByRole('button', { name: /Bỏ yêu thích/i }).click()
    await expect(page.getByRole('button', { name: 'Thêm vào yêu thích' })).toBeVisible()
  })
})