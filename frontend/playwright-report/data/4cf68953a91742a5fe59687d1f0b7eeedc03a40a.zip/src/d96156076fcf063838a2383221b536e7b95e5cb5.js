import { test, expect } from '@playwright/test'
import { openProducts, openFirstProduct } from './helpers'

test.describe('Products and variants', () => {
  test('TC-06 product list loads', async ({ page }) => {
    await openProducts(page)
    await expect(page.locator('.product-card')).toHaveCount(await page.locator('.product-card').count())
  })

  test('TC-07 product detail loads', async ({ page }) => {
    await openFirstProduct(page)
    await expect(page.locator('.product-detail-page h1')).toBeVisible()
  })

  test('TC-08 search returns a catalog state', async ({ page }) => {
    await openProducts(page)
    const search = page.locator('input').filter({ has: undefined }).first()
    await search.fill('linen')
    await page.getByRole('button', { name: /Tìm|Lọc|Áp dụng/i }).first().click().catch(() => {})
    await expect(page.locator('.product-list, .product-grid, .product-card').first()).toBeVisible()
  })

  test('TC-09 color and size selectors are available', async ({ page }) => {
    await openFirstProduct(page)
    await expect(page.getByText('Màu sắc')).toBeVisible()
    await expect(page.getByText('Kích cỡ')).toBeVisible()
    await expect(page.locator('.detail-swatch-row button').first()).toBeVisible()
    await expect(page.locator('.detail-size-row button').first()).toBeVisible()
  })

  test('TC-10 missing product shows empty state', async ({ page }) => {
    await page.goto('/#product-detail?id=999999')
    await expect(page.getByText(/Không tìm thấy sản phẩm|Không đọc được sản phẩm/i)).toBeVisible()
  })

  test('TC-11 selecting color changes active variant', async ({ page }) => {
    await openFirstProduct(page)
    const colors = page.locator('.detail-swatch-row button')
    if (await colors.count() > 1) {
      await colors.nth(1).click()
      await expect(colors.nth(1)).toHaveClass(/active/)
    }
  })

  test('TC-12 selecting size changes active variant', async ({ page }) => {
    await openFirstProduct(page)
    const sizes = page.locator('.detail-size-row button')
    if (await sizes.count() > 1) {
      await sizes.nth(1).click()
      await expect(sizes.nth(1)).toHaveClass(/active/)
    }
  })

  test('TC-13 quantity stepper never exceeds selected stock', async ({ page }) => {
    await openFirstProduct(page)
    const plus = page.locator('.detail-quantity-stepper button').last()
    for (let index = 0; index < 30; index += 1) await plus.click()
    await expect(page.locator('.detail-stock-pill')).toBeVisible()
  })
})