import { test, expect } from '@playwright/test'
import { registerCustomer, uniqueEmail } from './helpers'

test.describe('Authentication', () => {
  test('TC-01 register succeeds', async ({ page }) => {
    await registerCustomer(page)
    await expect(page.getByText(/Đăng ký thành công/i)).toBeVisible()
  })

  test('TC-02 duplicate email is rejected', async ({ page }) => {
    const account = await registerCustomer(page)
    await page.goto('/#register')
    await page.getByLabel('Họ và tên').fill('Duplicate')
    await page.getByLabel('Email').fill(account.email)
    await page.locator('form input[type="password"]').fill(account.password)
    await page.getByLabel('Số điện thoại').fill('0900000012')
    await page.getByLabel('Địa chỉ').fill('Duplicate address')
    await page.locator('form').getByRole('button', { name: 'Đăng ký', exact: true }).click()
    await expect(page.getByText(/Đăng ký thất bại/i)).toBeVisible()
  })

  test('TC-03 login succeeds', async ({ page }) => {
    const account = await registerCustomer(page)
    await page.getByLabel('Email').fill(account.email)
    await page.locator('form input[type="password"]').fill(account.password)
    await page.locator('form').getByRole('button', { name: 'Đăng nhập', exact: true }).click()
    await expect(page).toHaveURL(/#home$/)
  })

  test('TC-04 wrong password is rejected', async ({ page }) => {
    const account = await registerCustomer(page)
    await page.getByLabel('Email').fill(account.email)
    await page.locator('form input[type="password"]').fill('wrong-password')
    await page.locator('form').getByRole('button', { name: 'Đăng nhập', exact: true }).click()
    await expect(page.getByText(/Đăng nhập thất bại/i)).toBeVisible()
  })

  test('TC-05 invalid register fields show validation', async ({ page }) => {
    await page.goto('/#register')
    await page.locator('form').getByRole('button', { name: 'Đăng ký', exact: true }).click()
    await expect(page.getByText('Email không hợp lệ.')).toBeVisible()
    await expect(page.getByText('Vui lòng nhập họ và tên.')).toBeVisible()
  })
})