import { test, expect } from '@playwright/test'
import { openProducts } from './helpers'

test.describe('Search and filtering', () => {
  test('TC-14 category filter controls render', async ({ page }) => {
    await openProducts(page)
    await expect(page.getByText(/Bộ lọc|Danh mục|Màu sắc/i).first()).toBeVisible()
  })

  test('TC-15 sort control is usable', async ({ page }) => {
    await openProducts(page)
    const sort = page.locator('select').first()
    if (await sort.count()) {
      await sort.selectOption({ index: 0 })
      await expect(sort).toBeVisible()
    }
  })

  test('TC-16 reset filters is available', async ({ page }) => {
    await openProducts(page)
    const reset = page.getByRole('button', { name: /Đặt lại|Xóa lọc/i })
    if (await reset.count()) await expect(reset).toBeVisible()
  })
})